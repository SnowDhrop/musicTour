# Test

musicTour.getAll(styles, artists, output)
